package com.artesano.artesano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtesanoApplicationTests {

	@Test
	void contextLoads() {
	}

}
