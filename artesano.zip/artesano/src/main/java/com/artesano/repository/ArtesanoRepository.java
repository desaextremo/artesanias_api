package com.artesano.repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.artesano.model.Artesano;


@Repository
public interface ArtesanoRepository extends JpaRepository<Artesano, Long> {
    Page<Artesano> findByMunicipio_Departamento_DeptId(String deptId, Pageable pageable);
    Page<Artesano> findByMunicipio_Departamento_DeptIdAndMunicipio_MunId(String deptId, String munId, Pageable pageable);
    Page<Artesano> findByArtNombresStartingWith(String letra, Pageable pageable);
    Page<Artesano> findByArtApellidosStartingWith(String letra, Pageable pageable);
    Page<Artesano> findByArtGenero(Character genero, Pageable pageable);
}
