package com.artesano.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.artesano.model.ImagenArtesano;

@Repository
public interface ImagenArtesanoRepository extends JpaRepository<ImagenArtesano, Long> {
    List<ImagenArtesano> findByArtesano_ArtId(Integer artId);
}
