package com.artesano.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.artesano.model.Municipio;
@Repository
public interface MunicipioRepository extends JpaRepository<Municipio, String> {
    List <Municipio> findByDepartamento_DeptId(String deptId);
}