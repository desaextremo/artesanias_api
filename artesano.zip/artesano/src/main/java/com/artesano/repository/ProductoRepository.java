package com.artesano.repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.artesano.model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {
    Page<Producto> findByArtesano_ArtId(Long artId, Pageable pageable);
    Page<Producto> findByProdPrecioBetween(Double minPrice, Double maxPrice, Pageable pageable);
    Page<Producto> findByCategoriaProducto_CatProdId(Integer catProdId, Pageable pageable);
    Page<Producto> findByProdNombreContainingOrProdDescripcionContaining(String name, String description, Pageable pageable);    
}