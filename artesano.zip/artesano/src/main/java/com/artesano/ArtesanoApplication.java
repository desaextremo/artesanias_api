package com.artesano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtesanoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtesanoApplication.class, args);
	}

}
