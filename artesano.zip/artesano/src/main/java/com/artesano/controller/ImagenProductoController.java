package com.artesano.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.artesano.model.ImagenProducto;
import com.artesano.service.ImagenProductoService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ImagenProductoController {

    @Autowired
    private ImagenProductoService imagenProductoService;

    @GetMapping("/imagenes/producto/{prodId}")
    public List<ImagenProducto> getImagenesByProductoId(@PathVariable Integer prodId) {
        return imagenProductoService.findByProductoId(prodId);
    }
}