package com.artesano.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import com.artesano.model.Municipio;
import com.artesano.service.MunicipioService;
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class MunicipioController {
     @Autowired
    private MunicipioService municipioService;
    @GetMapping("/municipios")
    public Page<Municipio> findAll(Pageable pageable) {
        return municipioService.findAll(pageable);
    }
    
    @GetMapping("/municipios/{deptId}")
    public  List<Municipio> findByDeptId(@PathVariable String deptId) {
        return municipioService.findByDeptId(deptId);
    }
}