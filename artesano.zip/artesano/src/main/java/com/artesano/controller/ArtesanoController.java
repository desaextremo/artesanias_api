package com.artesano.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import com.artesano.model.Artesano;
import com.artesano.service.ArtesanoService;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ArtesanoController {

    @Autowired
    private ArtesanoService artesanoService;

    @GetMapping("/artesanos")
    public Page<Artesano> findAll(Pageable pageable) {
        return artesanoService.findAll(pageable);
    }
    
    @GetMapping("/artesanos/{artId}")
    public Optional<Artesano> findByArtId(@PathVariable Long artId) {
        return artesanoService.findByArtId(artId);
    }

    @GetMapping("/artesanos/departamento/{deptId}")
    public Page<Artesano> getArtesanosByDeptId(@PathVariable String deptId, Pageable pageable) {
        return artesanoService.findByDeptId(deptId, pageable);
    }

    @GetMapping("/artesanos/departamento/{deptId}/municipio/{munId}")
    public Page<Artesano> getArtesanosByDeptIdAndMunId(@PathVariable String deptId, @PathVariable String munId, Pageable pageable) {
        return artesanoService.findByDeptIdAndMunId(deptId, munId, pageable);
    }

    @GetMapping("/artesanos/nombres/{letra}")
    public Page<Artesano> getArtesanosByNombreInicial(@PathVariable String letra, Pageable pageable) {
        return artesanoService.findByNombreInicial(letra, pageable);
    }

    @GetMapping("/artesanos/apellidos/{letra}")
    public Page<Artesano> getArtesanosByApellidoInicial(@PathVariable String letra, Pageable pageable) {
        return artesanoService.findByApellidoInicial(letra, pageable);
    }

    @GetMapping("/artesanos/genero/{genero}")
    public Page<Artesano> getArtesanosByGenero(@PathVariable String genero, Pageable pageable) {
        return artesanoService.findByGenero(genero, pageable);
    }
}