package com.artesano.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.artesano.model.ImagenArtesano;
import com.artesano.service.ImagenArtesanoService;
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ImagenArtesanoController {

    @Autowired
    private ImagenArtesanoService imagenArtesanoService;

    @GetMapping("/imagenes/artesano/{artId}")
    public List<ImagenArtesano> getImagenesByArtesanoId(@PathVariable Integer artId) {
        return imagenArtesanoService.findByArtesanoId(artId);
    }
}
