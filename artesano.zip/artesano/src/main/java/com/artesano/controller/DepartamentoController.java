package com.artesano.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import com.artesano.model.Departamento;
import com.artesano.service.DepartamentoService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class DepartamentoController {
    @Autowired
    private DepartamentoService departamentoService;

    @GetMapping("/departamentos")
    public Page<Departamento> findAll(Pageable pageable) {
        return departamentoService.findAll(pageable);
    }
    
    @GetMapping("/departamentos/{deptId}")
    public Optional<Departamento> findByDeptId(@PathVariable String deptId) {
        return departamentoService.findByDeptId(deptId);
    }
}