package com.artesano.controller;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import com.artesano.model.Producto;
import com.artesano.service.ProductoService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @GetMapping("/productos")
    public Page<Producto> findAll(Pageable pageable) {
        return productoService.findAll(pageable);
    }
    
    @GetMapping("/productos/{prodId}")
    public Optional<Producto> findByProdId(@PathVariable Long prodId) {
        return productoService.findByProdId(prodId);
    }

    @GetMapping("/productos/artesano/{artId}")
    public Page<Producto> getProductosByArtesanoId(@PathVariable Long artId, Pageable pageable) {
        return productoService.findByArtesanoId(artId, pageable);
    }

    @GetMapping("/productos/precio")
    public Page<Producto> getProductosByPrecioRange(@RequestParam Double minPrice, @RequestParam Double maxPrice, Pageable pageable) {
        return productoService.findByPrecioRange(minPrice, maxPrice, pageable);
    }

    @GetMapping("/productos/categoria/{catProdId}")
    public Page<Producto> getProductosByCategoriaId(@PathVariable Integer catProdId, Pageable pageable) {
        return productoService.findByCategoriaId(catProdId, pageable);
    }

    @GetMapping("/productos/busqueda")
    public Page<Producto> getProductosByNameOrDescription(@RequestParam String query, Pageable pageable) {
        return productoService.findByNameOrDescription(query, query, pageable);
    }
}