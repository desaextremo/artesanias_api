package com.artesano.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.Data;


@Data
@Entity
@Table(name = "departamento")
public class Departamento {
    @Id
    @Column(name="dept_id")
    private String deptId;

    @Column(name="dept_nombre", nullable = false, length = 50)
    private String deptNombre;
    
    @OneToMany(mappedBy = "departamento")
    @JsonIgnore
    private List<Municipio> municipios;
}
