package com.artesano.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Data
@Entity
@Table(name = "producto")
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="prod_id")
    private Long prodId;

    @Column(name="prod_nombre",nullable = false, length = 255)
    private String prodNombre;

    @Column(name = "prod_precio",nullable = false)
    private Double prodPrecio;

    @Column(name="prod_descripcion", nullable = false, length = 255)
    private String prodDescripcion;

    @Column(name="prod_stock",nullable = false)
    private Integer prodStock;

    @ManyToOne
    @JoinColumn(name = "prod_cat_id", nullable = false)
    private CategoriaProducto categoriaProducto;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "prod_art_id", nullable = false)
    @JsonIgnore
    private Artesano artesano;

    @OneToMany(mappedBy = "producto")
    private List<ImagenProducto> imagenes;
}
