package com.artesano.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "imagen_producto")
public class ImagenProducto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="img_prod_id")
    private Integer imgProdId;

    @Column(name="img_prod_url",nullable = false, length = 255)
    private String imgProdUrl;

    @Column(name="img_prod_descripcion",columnDefinition = "TEXT")
    private String imgProdDescripcion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "img_prod_prod_id", nullable = false)
    @JsonIgnore
    private Producto producto;
}
