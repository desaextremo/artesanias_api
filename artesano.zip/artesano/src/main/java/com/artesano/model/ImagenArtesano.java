package com.artesano.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "imagen_artesano")
public class ImagenArtesano {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="img_art_id")
    private Integer imgArtId;

    @Column(name="img_art_url",nullable = false, length = 255)
    private String imgArtUrl;

    @Column(name="img_art_descripcion",columnDefinition = "TEXT")
    private String imgArtDescripcion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "img_art_artesano_id", nullable = false)
    @JsonIgnore
    private Artesano artesano;
}
