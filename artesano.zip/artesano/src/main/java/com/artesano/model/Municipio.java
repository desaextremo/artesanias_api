package com.artesano.model;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "municipio")
public class Municipio {
    @Id
    @Column(name="mun_id")
    private String munId;

    @Column(name = "mun_nombre",nullable = false, length = 50)
    private String munNombre;

    @ManyToOne
    @JoinColumn(name = "mun_dept_id", nullable = false)
    private Departamento departamento;

    @OneToMany(mappedBy = "municipio")
    @JsonIgnore
    private List<Artesano> artesanos;
}
