package com.artesano.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;
import java.util.List;


@Data
@Entity
@Table(name = "artesano")
public class Artesano {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "art_id")
    private Long artId;

    @Column(name="art_nombres",nullable = false, length = 50)
    private String artNombres;

    @Column(name="art_apellidos",nullable = false, length = 50)
    private String artApellidos;

    @Column(name="art_razon_social",nullable = false, length = 150)
    private String artRazonSocial;

    @Column(name="art_descripccion",columnDefinition = "TEXT")
    private String artDescripcion;

    @Column(name="art_email",nullable = false, length = 50)
    private String artEmail;

    @Column(name="art_celular",nullable = false, length = 10)
    private String artCelular;

    @Column(name = "art_genero",nullable = false)
    private Character artGenero; 

    @Column(name = "art_fecha_nacimiento",nullable = false)
    private LocalDate artFechaNacimiento;

    @Column(name = "art_picture")
    private String artPicture;

    @ManyToOne
    @JoinColumn(name = "art_mun_id", nullable = false)
    private Municipio municipio;

    @OneToMany(mappedBy = "artesano")
    private List<Producto> productos;

    @OneToMany(mappedBy = "artesano", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<ImagenArtesano> imagenes;
    
}