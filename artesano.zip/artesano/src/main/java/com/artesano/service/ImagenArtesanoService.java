package com.artesano.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.artesano.model.ImagenArtesano;
import com.artesano.repository.ImagenArtesanoRepository;

@Service
public class ImagenArtesanoService {
    @Autowired
    private ImagenArtesanoRepository imagenArtesanoRepository;

    public List<ImagenArtesano> findByArtesanoId(Integer artId) {
        return imagenArtesanoRepository.findByArtesano_ArtId(artId);
    }
}