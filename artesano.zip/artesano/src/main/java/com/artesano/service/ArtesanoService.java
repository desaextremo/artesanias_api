package com.artesano.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.artesano.model.Artesano;
import com.artesano.repository.ArtesanoRepository;

@Service
public class ArtesanoService {
    @Autowired
    private ArtesanoRepository artesanoRepository;

    public Page<Artesano> findAll(Pageable pageable) {
        return artesanoRepository.findAll(pageable);
    }

    public Optional<Artesano> findByArtId(Long id) {
        return artesanoRepository.findById(id);
    }

    public Page<Artesano> findByDeptId(String deptId, Pageable pageable) {
        return artesanoRepository.findByMunicipio_Departamento_DeptId(deptId, pageable);
    }

    public Page<Artesano> findByDeptIdAndMunId(String deptId, String munId, Pageable pageable) {
        return artesanoRepository.findByMunicipio_Departamento_DeptIdAndMunicipio_MunId(deptId, munId, pageable);
    }

    public Page<Artesano> findByNombreInicial(String letra, Pageable pageable) {
        return artesanoRepository.findByArtNombresStartingWith(letra, pageable);
    }

    public Page<Artesano> findByApellidoInicial(String letra, Pageable pageable) {
        return artesanoRepository.findByArtApellidosStartingWith(letra, pageable);
    }

    public Page<Artesano> findByGenero(String genero, Pageable pageable) {
        Character generoChar = genero.charAt(0); // Convertir String a Character
        return artesanoRepository.findByArtGenero(generoChar, pageable);
    }
}