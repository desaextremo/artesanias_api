package com.artesano.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.artesano.model.ImagenProducto;
import com.artesano.repository.ImagenProductoRepository;
@Service
public class ImagenProductoService {
    @Autowired
    private ImagenProductoRepository imagenProductoRepository;

    public List<ImagenProducto> findByProductoId(Integer prodId) {
        return imagenProductoRepository.findByProducto_ProdId(prodId);
    }
}