package com.artesano.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.artesano.model.Departamento;
import com.artesano.repository.DepartamentoRepository;
@Service
public class DepartamentoService {
    @Autowired
    private DepartamentoRepository departamentoRepository;

    public Page<Departamento> findAll(Pageable pageable) {
        return departamentoRepository.findAll(pageable);
    }

    public Optional<Departamento> findByDeptId(String id) {
        return departamentoRepository.findById(id);
    }
}