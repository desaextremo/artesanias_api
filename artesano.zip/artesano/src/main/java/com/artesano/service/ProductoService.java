package com.artesano.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.artesano.model.Producto;
import com.artesano.repository.ProductoRepository;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    public Optional<Producto> findByProdId(Long id) {
        return productoRepository.findById(id);
    }

     public Page<Producto> findAll(Pageable pageable) {
        return productoRepository.findAll(pageable);
    }

    public Page<Producto> findByArtesanoId(Long artId, Pageable pageable) {
        return productoRepository.findByArtesano_ArtId(artId, pageable);
    }

    public Page<Producto> findByPrecioRange(Double minPrice, Double maxPrice, Pageable pageable) {
        return productoRepository.findByProdPrecioBetween(minPrice, maxPrice, pageable);
    }

    public Page<Producto> findByCategoriaId(Integer catProdId, Pageable pageable) {
        return productoRepository.findByCategoriaProducto_CatProdId(catProdId, pageable);
    }

    public Page<Producto> findByNameOrDescription(String name, String description, Pageable pageable) {
        return productoRepository.findByProdNombreContainingOrProdDescripcionContaining(name, description, pageable);
    }
}
