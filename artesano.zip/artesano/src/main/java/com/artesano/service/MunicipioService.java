package com.artesano.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.artesano.model.Municipio;
import com.artesano.repository.MunicipioRepository;
@Service
public class MunicipioService {
    @Autowired
    private MunicipioRepository municipioRepository;
    public Page<Municipio> findAll(Pageable pageable) {
        return municipioRepository.findAll(pageable);
    }
    public List<Municipio> findByDeptId(String deptId) {
        return municipioRepository.findByDepartamento_DeptId(deptId);
    }
}